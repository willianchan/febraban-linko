﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Linko.Migrations
{
    public partial class maiscompletao : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Agente",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Email = table.Column<string>(nullable: false),
                    Senha = table.Column<string>(nullable: false),
                    CEP = table.Column<string>(nullable: false),
                    Validacao = table.Column<string>(nullable: false),
                    CPF = table.Column<string>(nullable: false),
                    Nome = table.Column<string>(nullable: false),
                    Telefone = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Agente", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Banco",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Email = table.Column<string>(nullable: false),
                    Senha = table.Column<string>(nullable: false),
                    Nome = table.Column<string>(nullable: false),
                    CNPJ = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Banco", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "LocalEntity",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CEP = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LocalEntity", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProdutoEntity",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Nome = table.Column<string>(nullable: false),
                    EpocaColheita = table.Column<string>(nullable: false),
                    EpocaPlantacao = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProdutoEntity", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Agricultores",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    ProdutoId = table.Column<int>(nullable: false),
                    LocalId = table.Column<int>(nullable: false),
                    Email = table.Column<string>(nullable: false),
                    Senha = table.Column<string>(nullable: false),
                    Nota = table.Column<int>(nullable: false),
                    BancoId = table.Column<int>(nullable: false),
                    AgenteId = table.Column<int>(nullable: false),
                    Nome = table.Column<string>(nullable: false),
                    BancoEntityId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Agricultores", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Agricultores_Agente_AgenteId",
                        column: x => x.AgenteId,
                        principalTable: "Agente",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Agricultores_Banco_BancoEntityId",
                        column: x => x.BancoEntityId,
                        principalTable: "Banco",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Agricultores_Banco_BancoId",
                        column: x => x.BancoId,
                        principalTable: "Banco",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Agricultores_LocalEntity_LocalId",
                        column: x => x.LocalId,
                        principalTable: "LocalEntity",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Agricultores_ProdutoEntity_ProdutoId",
                        column: x => x.ProdutoId,
                        principalTable: "ProdutoEntity",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Agricultores_AgenteId",
                table: "Agricultores",
                column: "AgenteId");

            migrationBuilder.CreateIndex(
                name: "IX_Agricultores_BancoEntityId",
                table: "Agricultores",
                column: "BancoEntityId");

            migrationBuilder.CreateIndex(
                name: "IX_Agricultores_BancoId",
                table: "Agricultores",
                column: "BancoId");

            migrationBuilder.CreateIndex(
                name: "IX_Agricultores_LocalId",
                table: "Agricultores",
                column: "LocalId");

            migrationBuilder.CreateIndex(
                name: "IX_Agricultores_ProdutoId",
                table: "Agricultores",
                column: "ProdutoId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Agricultores");

            migrationBuilder.DropTable(
                name: "Agente");

            migrationBuilder.DropTable(
                name: "Banco");

            migrationBuilder.DropTable(
                name: "LocalEntity");

            migrationBuilder.DropTable(
                name: "ProdutoEntity");
        }
    }
}
