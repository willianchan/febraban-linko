﻿using Linko.Models;

namespace Linko.Repository
{
    public interface IAgenteRepository
    {
        void Salvar(AgenteCreditoRuralEntity agenteEntity);
    }
}