﻿using Linko.Models;
using System.Collections.Generic;

namespace Linko.Repository
{
    public class BancoRepository : IBancoRepository
    {
        private readonly ApplicationContext context;

        public BancoRepository()
        {
        }

        public BancoRepository(ApplicationContext context)
        {
            this.context = context;
        }

        public void Salvar(BancoEntity bancoEntity)
        {
            List<AgricultorEntity> agricultores = new List<AgricultorEntity>();
            context.Set<BancoEntity>().Add(new BancoEntity(bancoEntity.CNPJ, bancoEntity.Email, bancoEntity.Nome, bancoEntity.Senha, agricultores));
        }

    }
}