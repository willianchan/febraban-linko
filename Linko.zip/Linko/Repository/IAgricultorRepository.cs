﻿using Linko.Models;

namespace Linko.Repository
{
    public interface IAgricultorRepository
    {
        void Retornar(string email, string senha);
        void Salvar(AgricultorEntity agricultorEntity);
    }
}