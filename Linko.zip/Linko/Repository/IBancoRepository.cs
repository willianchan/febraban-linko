﻿using Linko.Models;

namespace Linko.Repository
{
    public interface IBancoRepository
    {
        void Salvar(BancoEntity bancoEntity);
    }
}