﻿using Linko.Models;
using System.Collections.Generic;

namespace Linko.Repository
{
    public class AgenteRepository : IAgenteRepository
    {
        private readonly ApplicationContext context;

        public AgenteRepository()
        {
        }

        public AgenteRepository(ApplicationContext context)
        {
            this.context = context;
        }

        public void Salvar(AgenteCreditoRuralEntity agenteEntity)
        {
            List<AgricultorEntity> agricultores = new List<AgricultorEntity>();
            context.Set<AgenteCreditoRuralEntity>().Add(new AgenteCreditoRuralEntity(agenteEntity.CEP, agenteEntity.CPF, agenteEntity.Email, agenteEntity.Nome, agenteEntity.Senha, agenteEntity.Telefone, agenteEntity.Validacao, agricultores));
        }

    }
}