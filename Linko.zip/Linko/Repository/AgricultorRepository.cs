﻿using Linko.Models;

namespace Linko.Repository
{
    public class AgricultorRepository : IAgricultorRepository
    {
        private readonly ApplicationContext context;

        public AgricultorRepository(ApplicationContext context)
        {
            this.context = context;
        }

        public AgricultorRepository()
        {
        }

        public void Salvar(AgricultorEntity agricultorEntity)
        {
            context.Set<AgricultorEntity>().Add(new AgricultorEntity(agricultorEntity.Produto, agricultorEntity.Local, agricultorEntity.Email, agricultorEntity.Senha, agricultorEntity.Nota, agricultorEntity.Banco, agricultorEntity.Agente, agricultorEntity.Nome));
        }

        public void Retornar(string email, string senha)
        {
            //context.Set<AgricultorEntity>();
            //var users = (from x in DbSet.()
            //             where x.email == txtEmail.Text
            //         select x);.FirstOrDefault();
        }



    }
}