﻿namespace Linko
{
    interface IDataService
    {
        void InicializaDB();
    }
}