﻿using Linko.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Linko
{
    public class ApplicationContext: DbContext
    {

        public DbSet<AgricultorEntity> Agricultores { get; set; }
        public DbSet<AgenteCreditoRuralEntity> Agente { get; set; }
        public DbSet<BancoEntity> Banco { get; set; }

        public ApplicationContext(DbContextOptions options) : base(options)
        {
        }

            protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                base.OnModelCreating(modelBuilder);

                modelBuilder.Entity<AgricultorEntity>().HasKey(t => t.Id);
                modelBuilder.Entity<AgricultorEntity>().HasOne(t => t.Produto);
                modelBuilder.Entity<AgricultorEntity>().HasOne(t => t.Local);
                modelBuilder.Entity<AgricultorEntity>().HasOne(t => t.Banco);
                modelBuilder.Entity<AgricultorEntity>().HasOne(t => t.Agente);

                modelBuilder.Entity<AgenteCreditoRuralEntity>().HasKey(t => t.Id);
                modelBuilder.Entity<AgenteCreditoRuralEntity>().HasMany(t => t.Agricultores).WithOne(t => t.Agente);

                modelBuilder.Entity<BancoEntity>().HasKey(t => t.Id);
                modelBuilder.Entity<BancoEntity>().HasMany(t => t.Agricultores);


        }


    }
}
