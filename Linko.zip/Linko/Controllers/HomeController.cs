﻿using Linko.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Linko.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationContext context;

        public HomeController(ApplicationContext context)
        {
            this.context = context;
        }

        public IActionResult Index()
        {
            TempData["TipoUsuario"] = null;
            return View();
        }

        public IActionResult CadastrandoUsuario(string emailCad, string senhaCad, string tipoCad)
        {
            TempData["email"] = emailCad;
            TempData["senha"] = senhaCad;
            TempData["tipo"] = tipoCad;


            return View("CadastroPassoDois");

        }

        public IActionResult CadastroPassoDois()
        {
            return View();
        }
        public IActionResult MainAgricultor()
        {
            return View();
        }
        public IActionResult MainAgente()
        {
            return View();
        }

        public IActionResult CadastrandoFinalizado(string nomeCad, string cepCad, string nomeProdutoCad, string epocaPlantacaoProdutoCad, string epocaColheitaProdutoCad, byte[] fotoEquipamentoCad, string cpfCad, string telefoneCad, string cnpjCad)
        {


            string tipo = TempData["tipo"] as String;
            string emailCad = TempData["email"] as String;
            string senhaCad = TempData["senha"] as String;

            int nota = 1;/*Interacao.DO.WILLIAN;*/

            /* CRIAR UM ENTITY SEGUNDO O TIPO DE USUARIO */

            if (tipo.Equals("agricultor"))
            {
                LocalEntity local = new LocalEntity(cepCad);
                ProdutoEntity produto = new ProdutoEntity(nomeProdutoCad, epocaColheitaProdutoCad, epocaPlantacaoProdutoCad);
                AgricultorEntity gravado = new AgricultorEntity(produto, local, emailCad, senhaCad, nota, null, null, nomeCad);

                context.Set<AgricultorEntity>().Add(new AgricultorEntity(gravado.Produto, gravado.Local, gravado.Email, gravado.Senha, gravado.Nota, gravado.Banco, gravado.Agente, gravado.Nome));

                List<AgenteCreditoRuralEntity> agentes = new List<AgenteCreditoRuralEntity>();
                AgenteCreditoRuralEntity ag1 = new AgenteCreditoRuralEntity("lucas@lucas.com", "123", "0438600", "Valido", "47976664808", "Lucas Simoes", "5565-2947", null);
                AgenteCreditoRuralEntity ag2 = new AgenteCreditoRuralEntity("algusto@lucas.com", "123", "0458660", "Valido", "47933664808", "Algusto Carrara", "5543-2149", null);
                AgenteCreditoRuralEntity ag3 = new AgenteCreditoRuralEntity("adalberto@beto.com", "123", "1138600", "Valido", "41234664808", "Adalberto Beto", "5518-2910", null);
                AgenteCreditoRuralEntity ag4 = new AgenteCreditoRuralEntity("joao@zinho.com", "123", "0438220", "Valido", "479876543808", "Joao Zelu", "5557-2977", null);
                AgenteCreditoRuralEntity ag5 = new AgenteCreditoRuralEntity("matheus@matheus.com", "123", "0158600", "Valido", "45557664808", "Matheus Andre", "7165-2917", null);
                AgenteCreditoRuralEntity ag6 = new AgenteCreditoRuralEntity("john@silva.com", "123", "0438678", "Valido", "47976675378", "John Silva", "0515-2142", null);
                AgenteCreditoRuralEntity ag7 = new AgenteCreditoRuralEntity("flavio@wees.com", "123", "0478340", "Valido", "41976662356", "Flavio Wees", "5585-2047", null);
                AgenteCreditoRuralEntity ag8 = new AgenteCreditoRuralEntity("marcelo@pereira.com", "123", "0478800", "Valido", "47971286408", "Marcelo Pereira", "5115-2946", null);
                AgenteCreditoRuralEntity ag9 = new AgenteCreditoRuralEntity("caio@paulista.com", "123", "0438686", "Valido", "49976664808", "Caio Paulista", "5215-4027", null);
                AgenteCreditoRuralEntity ag10 = new AgenteCreditoRuralEntity("alexandre@orvalho.com", "123", "0438230", "Valido", "01906604808", "Alexandre Orvalho", "5865-0047", null);

                agentes.Add(ag1);
                agentes.Add(ag2);
                agentes.Add(ag3);
                agentes.Add(ag4);
                agentes.Add(ag5);
                agentes.Add(ag6);
                agentes.Add(ag7);
                agentes.Add(ag8);
                agentes.Add(ag9);
                agentes.Add(ag10);
                return View("MainAgricultor", agentes);

            }

            if (tipo.Equals("agente"))
            {

                List<AgricultorEntity> agricultores = new List<AgricultorEntity>();
                AgricultorEntity a1 = new AgricultorEntity(new ProdutoEntity("Morango", "Fevereiro", "Agosto"),new LocalEntity("04378999"),"jonas@aaa.com", "123", 9,null, null, "Jonas" );
                AgricultorEntity a2 = new AgricultorEntity(new ProdutoEntity("Goiaba", "Marco", "Dezembro"), new LocalEntity("04238939"), "monathan@babede.com", "123", 9, null, null, "Monathan");
                AgricultorEntity a3 = new AgricultorEntity(new ProdutoEntity("Maracujá", "Abril", "Marco"), new LocalEntity("04234999"), "marcos@castro.com", "123", 8, null, null, "Marcos");
                AgricultorEntity a4 = new AgricultorEntity(new ProdutoEntity("Banana", "Janeiro", "Abril"), new LocalEntity("24454999"), "julqueira@almae.com", "123", 8, null, null, "Julqueira");
                AgricultorEntity a5 = new AgricultorEntity(new ProdutoEntity("Macã", "Dezembro", "Junho"), new LocalEntity("04368799"), "sona@luana.com", "123", 7, null, null, "Sona");
                AgricultorEntity a6 = new AgricultorEntity(new ProdutoEntity("Laranja", "Maio", "Agosto"), new LocalEntity("01318599"), "madelena@maria.com", "123", 7, null, null, "Madalena");
                AgricultorEntity a7 = new AgricultorEntity(new ProdutoEntity("Uva", "Junho", "Setembro"), new LocalEntity("04371429"), "elva@siqueira.com", "123", 7, null, null, "Elva");
                AgricultorEntity a8 = new AgricultorEntity(new ProdutoEntity("Mamão", "Agosto", "Marco"), new LocalEntity("04271349"), "manuel@silva.com", "123", 7, null, null, "Manuel");
                AgricultorEntity a9 = new AgricultorEntity(new ProdutoEntity("Abacaxi", "Abril", "Junho"), new LocalEntity("0118999"), "salvio@padliska.com", "123", 6, null, null, "Salvio");
                AgricultorEntity a10 = new AgricultorEntity(new ProdutoEntity("Ameixa", "Setembro", "Outubro"), new LocalEntity("22374949"), "thiago@yamamoto.com", "123", 6, null, null, "Thiago");


                agricultores.Add(a1);
                agricultores.Add(a2);
                agricultores.Add(a3);
                agricultores.Add(a4);
                agricultores.Add(a5);
                agricultores.Add(a6);
                agricultores.Add(a7);
                agricultores.Add(a8);
                agricultores.Add(a9);
                agricultores.Add(a10);
                return View("MainAgente", agricultores);

            }

            if (tipo.Equals("banco"))
            {
                List<AgenteCreditoRuralEntity> agentes = new List<AgenteCreditoRuralEntity>();
                AgenteCreditoRuralEntity ag1 = new AgenteCreditoRuralEntity("lucas@lucas.com", "123", "0438600", "Valido", "47976664808", "Lucas Simoes", "5565-2947", null);
                AgenteCreditoRuralEntity ag2 = new AgenteCreditoRuralEntity("algusto@lucas.com", "123", "0458660", "Valido", "47933664808", "Algusto Carrara", "5543-2149", null);
                AgenteCreditoRuralEntity ag3 = new AgenteCreditoRuralEntity("adalberto@beto.com", "123", "1138600", "Valido", "41234664808", "Adalberto Beto", "5518-2910", null);
                AgenteCreditoRuralEntity ag4 = new AgenteCreditoRuralEntity("joao@zinho.com", "123", "0438220", "Valido", "479876543808", "Joao Zelu", "5557-2977", null);
                AgenteCreditoRuralEntity ag5 = new AgenteCreditoRuralEntity("matheus@matheus.com", "123", "0158600", "Valido", "45557664808", "Matheus Andre", "7165-2917", null);
                AgenteCreditoRuralEntity ag6 = new AgenteCreditoRuralEntity("john@silva.com", "123", "0438678", "Valido", "47976675378", "John Silva", "0515-2142", null);
                AgenteCreditoRuralEntity ag7 = new AgenteCreditoRuralEntity("flavio@wees.com", "123", "0478340", "Valido", "41976662356", "Flavio Wees", "5585-2047", null);
                AgenteCreditoRuralEntity ag8 = new AgenteCreditoRuralEntity("marcelo@pereira.com", "123", "0478800", "Valido", "47971286408", "Marcelo Pereira", "5115-2946", null);
                AgenteCreditoRuralEntity ag9 = new AgenteCreditoRuralEntity("caio@paulista.com", "123", "0438686", "Valido", "49976664808", "Caio Paulista", "5215-4027", null);
                AgenteCreditoRuralEntity ag10 = new AgenteCreditoRuralEntity("alexandre@orvalho.com", "123", "0438230", "Valido", "01906604808", "Alexandre Orvalho", "5865-0047", null);

                agentes.Add(ag1);
                agentes.Add(ag2);
                agentes.Add(ag3);
                agentes.Add(ag4);
                agentes.Add(ag5);
                agentes.Add(ag6);
                agentes.Add(ag7);
                agentes.Add(ag8);
                agentes.Add(ag9);
                agentes.Add(ag10);
                return View("MainAgricultor", agentes);
            }
            return null;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
