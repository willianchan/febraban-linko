﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Linko.TO
{
    public class ProdutoTO
    {
        public int Id { get; set; }

        public string Nome { get; set; }
        
        public string EpocaColheita { get; set; }

        public string EpocaPlantacao { get; set; }



    }
}
