﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Linko.TO
{
    public class AgricultorTO
    {
        public AgricultorTO(string email, string senha, int nota, BancoTO banco, AgenteCreditoRuralTO agente, LocalTO local, ProdutoTO produto)
        {
            Email = email;
            Senha = senha;
            Nota = nota;
            Banco = banco;
            Agente = agente;
            Local = local;
            Produto = produto;
        }

        public int Id { get; set; }

        public string Email { get; set; }

        public string Senha { get; set; }

        public int Nota { get; set; }

        public BancoTO Banco { get; set; }

        public AgenteCreditoRuralTO Agente { get; set; }

        public LocalTO Local { get; set; }

        public ProdutoTO Produto { get; set; }

    }
}
