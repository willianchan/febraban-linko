﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Linko.Models
{
    public class AgricultorEntity : BaseModel
    {
        public AgricultorEntity()
        {
        }

        public AgricultorEntity(ProdutoEntity produto, LocalEntity local, string email, string senha, int nota, BancoEntity banco, AgenteCreditoRuralEntity agente, string nome)
        {
            Produto = produto;
            Local = local;
            Email = email;
            Senha = senha;
            Nota = nota;
            Banco = banco;
            Agente = agente;
            Nome = nome;
        }


        [Required]
        public ProdutoEntity Produto { get; set; }

        [Required]
        public LocalEntity Local { get; set; }

        [Required]
        public string Email { get; set; }

        [Required]
        public string Senha { get; set; }

        [Required]
        public int Nota { get; set; }

        [Required]
        public BancoEntity Banco { get; set; }

        [Required]
        public AgenteCreditoRuralEntity Agente { get; set; }

        [Required]
        public string Nome { get; set; }
    }
}
