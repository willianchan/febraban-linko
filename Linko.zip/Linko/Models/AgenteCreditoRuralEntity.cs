﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Linko.Models
{
    public class AgenteCreditoRuralEntity: BaseModel
    {
        public AgenteCreditoRuralEntity()
        {
        }

        public AgenteCreditoRuralEntity(string email, string senha, string cEP, string validacao, string cPF, string nome, string telefone, List<AgricultorEntity> agricultores)
        {
            Email = email;
            Senha = senha;
            CEP = cEP;
            Validacao = validacao;
            CPF = cPF;
            Nome = nome;
            Telefone = telefone;
            Agricultores = agricultores;
        }

        [Required]
        public string Email { get; set; }

        [Required]
        public string Senha { get; set; }

        [Required]
        public string CEP { get; set; }

        [Required]
        public string Validacao { get; set; } //SABER COMO VALIDAR ISSO NEGOCIO

        [Required]
        public string CPF { get; set; }

        [Required]
        public string Nome { get; set; }

        [Required]
        public string Telefone { get; set; }

        [Required]
        public List<AgricultorEntity> Agricultores { get; set; } = new List<AgricultorEntity>();

    }
}
