﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace Linko.Models
{
    public class BancoEntity: BaseModel
    {
        public BancoEntity()
        {
        }

        public BancoEntity(string email, string senha, string nome, string cNPJ, List<AgricultorEntity> agricultores)
        {
            Email = email;
            Senha = senha;
            Nome = nome;
            CNPJ = cNPJ;
            Agricultores = agricultores;
        }

        [Required]
        public string Email { get; set; }

        [Required]
        public string Senha { get; set; }

        [Required]
        public string Nome { get; set; }

        [Required]
        public string CNPJ { get; set; }

        [Required]
        public List<AgricultorEntity> Agricultores{ get; set; } = new List<AgricultorEntity>();


    }
}
