﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Linko.Models
{
    public class ProdutoEntity: BaseModel
    {
        public ProdutoEntity(string nome, string epocaColheita, string epocaPlantacao)
        {
            Nome = nome;
            EpocaColheita = epocaColheita;
            EpocaPlantacao = epocaPlantacao;
        }

        [Required]
        public string Nome { get; set; }

        [Required]
        public string EpocaColheita { get; set; }

        [Required]
        public string EpocaPlantacao { get; set; }

     }
}
